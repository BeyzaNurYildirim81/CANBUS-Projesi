
import pandas as pd
import numpy as np


data=pd.read_excel("Tum_alarmlar.xlsx")

# Tüm değerleri NaN olan sütunu sil
data = data.dropna(axis=1, how='all')

# NaN değerleri içeren satırları sil
data = data.dropna()

# NaN değerleri olan satırları filtrele
nan_satırları = data[data.isnull().any(axis=1)]

kolonlar=data.columns

# Bir kolondaki farklı verileri göster
farklı_veriler = data['Fiili retarder torku %'].unique()


# Hangi alarmlar var bakalım
alarmlar=data['Alarm Adı'].unique()


# "Alarm Adı" sütununu 
## Tahmin etmek istediğimiz event değerini 1 diğerlerini 0 yapalım
data['Alarm Adı'] = data['Alarm Adı'].apply(lambda x: 1 if 'Canbus Alarm : Fren balatası kalınlığı  ön aks  sol teker' in x else 0)
data.rename(columns={'Alarm Adı': 'Event durumu'}, inplace=True)
kolonlar=data.columns
#ihtiyacımız olmayacak olan kolonları silelim
silinecek_kolonlar = ['id', 'Tarih', 'Araç Id','imei','Değer','Fren balatası kalınlığı  ön aks  sol teker %']  # Silmek istediğiniz kolonların listesi
data = data.drop(silinecek_kolonlar, axis=1)

# Tüm sütunları göstermek için ayarı değiştir
pd.set_option('display.max_columns', None)

# Kolon veri tiplerini göster
veri_tipleri = data.dtypes

# Sonucu göster
# Her bir veri tipinden kaç adet olduğunu hesapla
#veri_tipi_sayilari = veri_tipleri.value_counts()
#veri_tipi_sayilari
# Float olmayan kolonları filtrele
filtre = ~veri_tipleri.isin([float])
float_olmayan_kolonlar = veri_tipleri[filtre].index
#Sorun oluşturanlar object olanlar
#object kolonlar
object_kolonlar=data.select_dtypes(include='object').columns


# object_dizisi=[]
# for i in object_kolonlar:
#     object_dizisi.append(data[i].unique())
#     #print(data[i].unique())

#object kolonları sayısal değere dönüştürüyoruz
from sklearn.preprocessing import LabelEncoder
donusecekler=['DM1 motor ', 'DM1 fren ', 'DM1 süspansiyon ', 'Klima durumu ',
       'Gaz Pedalı Kick Down Müşiri  ', 'Seçilen vites ', 'EBS Fren Müşiri ',
       'Mevcut vites ', 'Durdurma fren modu ', 'Yokuş kalkış desteği modu ',
       '1. Kapının Açık Durumu ', '2. Kapının Açık Durumu ',
       '3. Kapının Açık Durumu ', '4. Kapının Açık Durumu ',
       'Park fren müşiri ', 'Hava Kompresör Durumu ', 'DM1 şanzıman ',
       'Alternatör Durumu 1 ', 'Alternatör Durumu 2 ', 'Alternatör Durumu 3 ']
for i in donusecekler:
    encoder = LabelEncoder()
    data[i] = encoder.fit_transform(data[i])

# # object verileri category e çevirmek gerekirse
# columns = ['DM1 motor ', 'DM1 fren ', 'DM1 süspansiyon ', 'Klima durumu ',
#        'Gaz Pedalı Kick Down Müşiri  ', 'Seçilen vites ', 'EBS Fren Müşiri ',
#        'Mevcut vites ', 'Durdurma fren modu ', 'Yokuş kalkış desteği modu ',
#        '1. Kapının Açık Durumu ', '2. Kapının Açık Durumu ',
#        '3. Kapının Açık Durumu ', '4. Kapının Açık Durumu ',
#        'Park fren müşiri ', 'Hava Kompresör Durumu ', 'DM1 şanzıman ',
#        'Alternatör Durumu 1 ', 'Alternatör Durumu 2 ', 'Alternatör Durumu 3 ']

# data[columns] = data[columns].astype('category')
# data


# object_dizisi2=[]
# for i in object_kolonlar:
#     object_dizisi2.append(data[i].unique())
#     print(data[i].unique())

#data hakkında bilgi alalım
data_info=data.info()

# # # desicion tree modeli
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

X = data.drop('Event durumu', axis=1)
y = data['Event durumu']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = DecisionTreeClassifier()
model.fit(X_train, y_train)


#get_ipython().system('pip install pydotplus')
#get_ipython().system('pip install graphviz')

#Ağacın yapısını anlamak için görselleştirme yapacağız
import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files (x86)/Graphviz2.38/bin/' # Graphviz'in yüklendiği konumu doğru şekilde güncelleyin
#get_ipython().system('pip install dtreeviz')


from sklearn import tree
import graphviz
import pydotplus
from IPython.display import Image
# Karar ağacının görsel temsilini oluşturma
dot_data = tree.export_graphviz(model, out_file=None, feature_names=X.columns.astype(str), class_names=model.classes_.astype(str), filled=True)
graph = pydotplus.graph_from_dot_data(dot_data)

#görseli dosyaya da kaydedelim
from IPython.display import Image
# Görseli kaydetmek istediğimiz dosya yolu
dosya_yolu = "fren_balatasi_alarmi_agaci.png"
# Görseli oluşturalım
graph.write_png(dosya_yolu)
# Kaydedilen görseli görüntüle
Image(dosya_yolu)

#Dallanma sayısını öğrenelim
dallanma_sayisi = model.tree_.node_count
# print("Dallanma Sayısı:", dallanma_sayisi)

# #Ağacın dalları hakkında bilgi alalım
# def get_decision_conditions(tree, feature_names):
#     left_children = tree.tree_.children_left
#     right_children = tree.tree_.children_right
#     threshold_values = tree.tree_.threshold
#     feature_indices = tree.tree_.feature

#     conditions = []
#     for i in range(len(left_children)):
#         if left_children[i] == right_children[i]:  # Yaprak düğüm kontrolü
#             continue
#         feature_name = feature_names[feature_indices[i]]
#         threshold = threshold_values[i]
#         condition = f"{feature_name} <= {threshold}"
#         conditions.append(condition)
    
#     return conditions

# decision_conditions = get_decision_conditions(model, X.columns)
# for condition in decision_conditions:
#     print(condition)



# def get_leaf_node_values(tree):
#     leaf_values = tree.tree_.value
#     class_names = tree.classes_

#     leaf_results = []
#     for leaf in leaf_values:
#         class_probabilities = leaf / np.sum(leaf)
#         class_results = {class_name: class_prob for class_name, class_prob in zip(class_names, class_probabilities)}
#         leaf_results.append(class_results)

#     return leaf_results

# leaf_node_results = get_leaf_node_values(model)
# for i, result in enumerate(leaf_node_results):
#     print("Düğüm", i, "Karar Sonuçları:", result)


# #  devam, test edelim
y_pred = model.predict(X_test)
#Başarıyı inceleyelim
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

# print("Doğruluk (Accuracy):", accuracy)
# print("Hassasiyet (Precision):", precision)
# print("Kesinlik (Recall):", recall)
# print("F1 Skoru:", f1)

#başarıyı grafikle inceleyelim
import matplotlib.pyplot as plt
# Metrik değerlerini listeye ekle
metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
values = [accuracy, precision, recall, f1]

# Grafik çizimi
plt.figure(figsize=(8, 6))
plt.bar(metrics, values)
plt.title('Model Performansı')
plt.xlabel('Metrik')
plt.ylabel('Değer')
#plt.show()  #bunu grafik bölümünden görebilirsin


# # Gerçek veriyle test edelim
#Modeli kaydetmemiz gerekiyor
import pickle

# Modeli kaydetmek istediğiniz dosya yolunu belirleyin
dosya_yolu = "motor_yuku_arizasi_modeli.pkl"

# Modeli kaydetme
with open(dosya_yolu, 'wb') as dosya:
    pickle.dump(model, dosya)




# import pandas as pd

# # "Event değeri" kolonuyla diğer sayısal kolonlar arasındaki korelasyonu hesapla
# correlation_matrix = data.corr()

# # "Event değeri" kolonunun diğer kolonlarla olan korelasyonunu inceleyin
# event_correlations = correlation_matrix["Event durumu"].drop("Event durumu")

# # Korelasyon değerlerini büyükten küçüğe sıralayın
# sorted_correlations = event_correlations.abs().sort_values(ascending=False)

# # Tüm sonuçları göstermek için satır sınırlamasını kaldırın
# pd.set_option("display.max_rows", None)

# # Korelasyon sonuçlarını yazdırın
# print("Tüm Korelasyonlar:")
# print(sorted_correlations)

# # En büyük ve en küçük 10 korelasyonu gösterin
# top_10_correlations = sorted_correlations.head(10)
# bottom_10_correlations = sorted_correlations.tail(10)

# # Sonuçları yazdırın
# print("\nEn büyük 10 korelasyon:")
# print(top_10_correlations)
# korelasyon_tablosu=pd.DataFrame(top_10_correlations)
# korelasyon_tablosu=korelasyon_tablosu.rename(columns={'Event durumu': 'Korelasyon değeri'})
# # # print("\nEn küçük 10 korelasyon:")
# # # print(bottom_10_correlations)


# her özniteliğin önemini (feature_importance) yaz
# Öznitelik önemini alın
feature_importance =model.feature_importances_

# Öznitelik önemini yazdırın
for feature, importance in zip(X.columns, feature_importance):
    print(f"{feature}: {importance}")

#En büyük özellik ağırlıkları
# Öznitelikleri ve önemlerini birleştirin
feature_importance_df = pd.DataFrame({'Feature': X.columns, 'Importance': feature_importance})

# Öznitelik önemlerini sıralayın
sorted_feature_importance = feature_importance_df.sort_values(by='Importance', ascending=False)

# İlk 5 özniteliği gösterin
top_5_features = sorted_feature_importance.head(10)
print(top_5_features)
agirlik_tablo=pd.DataFrame(top_5_features)

# print(alarmlar)