# -*- coding: utf-8 -*-
"""
Arıza tahmini projesinde gerçek verilerle modelleri test etmek için yazılmıştır.
Hangii arızayı tahmin etmek istiyorsanız onu 1 yapmanız gerekiyor. Satır:45
"""

import pickle
dosya_yolu="motor_yuku_arizasi_modeli.pkl"
# Kaydedilen modeli yükleme
with open(dosya_yolu, 'rb') as dosya:
    model = pickle.load(dosya)

import pandas as pd

# "test_verileri.xlsx" dosyasını okuma
df = pd.read_excel("test_verileri.xlsx")

#son 10 kolonu silelim boş onlar
df = df.iloc[:, :-10]

# Tüm değerleri NaN olan sütunu sil
df = df.dropna(axis=1, how='all')

# NaN değerleri içeren satırları sil
df = df.dropna()

#ihtiyacımız olmayacak olan kolonları silelim
silinecek_kolonlar = ['id', 'Tarih', 'Araç Id','imei','Değer']  # Silmek istediğiniz kolonların listesi
df = df.drop(silinecek_kolonlar, axis=1)

## Tahmin etmek istediğimiz event değerini 1 diğerlerini 0 yapalım
df['Alarm Adı'] = df['Alarm Adı'].apply(lambda x: 1 if 'Canbus Alarm : Mevcut hızda yüzde olarak motor yükü' in x else 0)
#kolonun adını değiştiriyorduk
df.rename(columns={'Alarm Adı': 'Event durumu'}, inplace=True)

#object kolonları sayısal değere dönüştürüyoruz
from sklearn.preprocessing import LabelEncoder
donusecekler=['DM1 motor ', 'DM1 fren ', 'DM1 süspansiyon ', 'Klima durumu ',
       'Gaz Pedalı Kick Down Müşiri  ', 'Seçilen vites ', 'EBS Fren Müşiri ',
       'Mevcut vites ', 'Durdurma fren modu ', 'Yokuş kalkış desteği modu ',
       '1. Kapının Açık Durumu ', '2. Kapının Açık Durumu ',
       '3. Kapının Açık Durumu ', '4. Kapının Açık Durumu ',
       'Park fren müşiri ', 'Hava Kompresör Durumu ', 'DM1 şanzıman ',
       'Alternatör Durumu 1 ', 'Alternatör Durumu 2 ', 'Alternatör Durumu 3 ']
for i in donusecekler:
    encoder = LabelEncoder()
    df[i] = encoder.fit_transform(df[i])



#etiketi ayıralım
from sklearn.metrics import accuracy_score
X = df.drop('Event durumu', axis=1)
y = df['Event durumu'].reset_index(drop=True)   #indeks kaydığı için yanlış yönlendiriyordu düzelttim


# Modeli kullanarak tahminler yapma
tahminler = model.predict(X)

#Başarıyı inceleyelim
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

accuracy = accuracy_score(y, tahminler)
precision = precision_score(y, tahminler)
recall = recall_score(y, tahminler)
f1 = f1_score(y, tahminler)

print("Doğruluk (Accuracy):", accuracy)
print("Hassasiyet (Precision):", precision)
print("Kesinlik (Recall):", recall)
print("F1 Skoru:", f1)

y_df = pd.DataFrame({'dogru_sonuc': y})
tahminler_df = pd.DataFrame({'tahminler': tahminler})
sonuclar = pd.concat([y_df, tahminler_df], axis=1)









